﻿namespace SportsTeamDBMS.Models
{
    public class PlayerViewModel
    {
        public int PlayerID { get; set; }
        public string? PlayerName { get; set; }
        public string? Position { get; set; }
        public int JerseyNumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string? Nationality { get; set; }
        public DateTime JoiningDate { get; set; }
        public string? TeamName { get; set; }
    }

}
