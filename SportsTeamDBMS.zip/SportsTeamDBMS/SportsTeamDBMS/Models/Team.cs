﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportsTeamDBMS.Models
{
    public class Team
    {
        [Key]
        public int TeamID { get; set; }

        [Required(ErrorMessage = "Team Name is required"), MaxLength(100, ErrorMessage = "Team Name cannot exceed 100 characters")]
        public string? TeamName { get; set; }

        [MaxLength(50, ErrorMessage = "City cannot exceed 50 characters")]
        public string? City { get; set; }

        [MaxLength(100, ErrorMessage = "Coach Name cannot exceed 100 characters")]
        public string? CoachName { get; set; }

        [MaxLength(100, ErrorMessage = "Stadium cannot exceed 100 characters")]
        public string? Stadium { get; set; }

        public int EstablishedYear { get; set; }

        public ICollection<Player>? Players { get; set; }
        public ICollection<Staff>? Staff { get; set; }
    }
}
