﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportsTeamDBMS.Models
{
    public class Staff
    {
        [Key]
        public int StaffID { get; set; }

        [Required(ErrorMessage = "Staff Name is required"), MaxLength(100, ErrorMessage = "Staff Name cannot exceed 100 characters")]
        public string? StaffName { get; set; }

        [MaxLength(50, ErrorMessage = "Role cannot exceed 50 characters")]
        public string? Role { get; set; }

        [ForeignKey("Team")]
        public int TeamID { get; set; }
        public virtual Team? Team { get; set; }
    }
}
