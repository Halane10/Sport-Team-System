﻿namespace SportsTeamDBMS.Models
{
    public class GameViewModel
    {
        public int GameID { get; set; }
        public string? HomeTeam { get; set; }
        public string? AwayTeam { get; set; }
        public DateTime GameDate { get; set; }
        public string? Stadium { get; set; }
        public string? Referee { get; set; }
        public string? Result { get; set; }
    }

}
