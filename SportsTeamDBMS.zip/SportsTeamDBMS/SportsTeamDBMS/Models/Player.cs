﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportsTeamDBMS.Models
{
    public class Player
    {
        [Key]
        public int PlayerID { get; set; }

        [Required(ErrorMessage = "Player Name is required"), MaxLength(100, ErrorMessage = "Player Name cannot exceed 100 characters")]
        public string? PlayerName { get; set; }

        [ForeignKey("Team")]
        public int TeamID { get; set; }
        public virtual Team? Team { get; set; }

        [MaxLength(50, ErrorMessage = "Position cannot exceed 50 characters")]
        public string? Position { get; set; }

        public int JerseyNumber { get; set; }

        public DateTime DateOfBirth { get; set; }

        [MaxLength(50, ErrorMessage = "Nationality cannot exceed 50 characters")]
        public string? Nationality { get; set; }

        public DateTime JoiningDate { get; set; }

        public ICollection<PlayerStatistic>? PlayerStatistics { get; set; }
    }
}
