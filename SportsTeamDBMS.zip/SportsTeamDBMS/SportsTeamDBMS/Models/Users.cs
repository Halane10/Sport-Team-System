﻿using Microsoft.AspNetCore.Identity;

namespace SportsTeamDBMS.Models
{
    public class Users : IdentityUser
    {
        public string FullName { get; set; }

    }
}