﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportsTeamDBMS.Models
{
    public class PlayerStatistic
    {
        [Key]
        public int PlayerStatID { get; set; }

        [Required]
        public int GameID { get; set; }

        [Required]
        public int PlayerID { get; set; }

        [Required]
        public int TeamID { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Goals cannot be negative")]
        public int Goals { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Assists cannot be negative")]
        public int Assists { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Yellow cards cannot be negative")]
        public int YellowCards { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Red cards cannot be negative")]
        public int RedCards { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Minutes played cannot be negative")]
        public int MinutesPlayed { get; set; }

        public virtual Game? Game { get; set; }
        public virtual Player? Player { get; set; }
        public virtual Team? Team { get; set; }
    }
}
