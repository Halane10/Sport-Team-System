﻿namespace SportsTeamDBMS.Models
{
    public class PlayerStatisticViewModel
    {
        public int PlayerStatID { get; set; }
        public int PlayerID { get; set; }
        public int TeamID { get; set; }
        public int GameID { get; set; }
        public int Goals { get; set; }
        public int Assists { get; set; }
        public int YellowCards { get; set; }
        public int RedCards { get; set; }
        public int MinutesPlayed { get; set; }
        public string? PlayerName { get; set; }
        public string? TeamName { get; set; }
        public DateTime GameDate { get; set; }
    }

}
