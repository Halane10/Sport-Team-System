﻿namespace SportsTeamDBMS.Models
{
    public class StaffViewModel
    {
        public int StaffID { get; set; }
        public string? StaffName { get; set; }
        public string? Role { get; set; }
        public string? TeamName { get; set; }
    }

}
