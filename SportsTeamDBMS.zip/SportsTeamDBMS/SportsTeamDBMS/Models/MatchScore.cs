﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportsTeamDBMS.Models
{
    public class MatchScore
    {
        [Key]
        public int MatchScoreID { get; set; }

        [ForeignKey("Game")]
        public int GameID { get; set; }
        public virtual Game? Game { get; set; }

        [ForeignKey("Team")]
        public int TeamID { get; set; }
        public virtual Team? Team { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "GoalsScored cannot be negative")]
        public int GoalsScored { get; set; }
    }
}
