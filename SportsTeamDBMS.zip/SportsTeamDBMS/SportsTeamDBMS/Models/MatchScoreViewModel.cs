﻿namespace SportsTeamDBMS.Models
{
    public class MatchScoreViewModel
    {
        public int MatchScoreID { get; set; }
        public string? TeamName { get; set; }
        public int GoalsScored { get; set; }
        public DateTime GameDate { get; set; }
    }

}
