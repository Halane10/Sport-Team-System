﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportsTeamDBMS.Models
{
    public class Game
    {
        [Key]
        public int GameID { get; set; }

        // Foreign Key properties for teams
        [ForeignKey("HomeTeam")]
        public int HomeTeamID { get; set; }
        public virtual Team? HomeTeam { get; set; }

        [ForeignKey("AwayTeam")]
        public int AwayTeamID { get; set; }
        public virtual Team? AwayTeam { get; set; }

        // Other properties...
        public DateTime GameDate { get; set; }
        [MaxLength(100, ErrorMessage = "Stadium cannot exceed 100 characters")]
        public string? Stadium { get; set; }
        [MaxLength(100, ErrorMessage = "Referee cannot exceed 100 characters")]
        public string? Referee { get; set; }
        [MaxLength(50, ErrorMessage = "Result cannot exceed 50 characters")]
        public string? Result { get; set; }

        public ICollection<PlayerStatistic>? PlayerStatistics { get; set; }
        public ICollection<MatchScore>? MatchScores { get; set; }
    }
}
