﻿namespace SportsTeamDBMS.Models
{
    public class TeamViewModel
    {
        public int TeamID { get; set; }
        public string TeamName { get; set; }
        public string City { get; set; }
        public string CoachName { get; set; }
        public string Stadium { get; set; }
        public int EstablishedYear { get; set; }
    }

}
