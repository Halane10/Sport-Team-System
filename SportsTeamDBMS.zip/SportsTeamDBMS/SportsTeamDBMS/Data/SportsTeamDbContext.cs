﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SportsTeamDBMS.Models;

namespace SportsTeamDBMS.Data
{
    public class SportsTeamDbContext : IdentityDbContext<Users>
    {
        public SportsTeamDbContext(DbContextOptions options) : base(options)
        {
        }


        // DbSet properties for tables
        public DbSet<Team> Teams { get; set; }
        public DbSet<Player> Players { get; set; }
        public DbSet<Game> Games { get; set; }
        public DbSet<MatchScore> MatchScores { get; set; }
        public DbSet<PlayerStatistic> PlayerStatistics { get; set; }
        public DbSet<Staff> Staffs { get; set; }

        public DbSet<TeamViewModel> TeamView { get; set; }
        public DbSet<PlayerViewModel> PlayerView { get; set; }
        public DbSet<GameViewModel> GameView { get; set; }
        public DbSet<MatchScoreViewModel> MatchScoreView { get; set; }
        public DbSet<PlayerStatisticViewModel> PlayerStatisticView { get; set; }
        public DbSet<StaffViewModel> StaffView { get; set; }
        
       


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Define relationships for key-based entities
            modelBuilder.Entity<Team>()
                .HasMany(t => t.Players)
                .WithOne(p => p.Team)
                .HasForeignKey(p => p.TeamID);

            modelBuilder.Entity<Team>()
                .HasMany(t => t.Staff)
                .WithOne(s => s.Team)
                .HasForeignKey(s => s.TeamID);

            modelBuilder.Entity<Game>()
                .HasOne(g => g.HomeTeam)
                .WithMany()
                .HasForeignKey(g => g.HomeTeamID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Game>()
                .HasOne(g => g.AwayTeam)
                .WithMany()
                .HasForeignKey(g => g.AwayTeamID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PlayerStatistic>()
                .HasOne(ps => ps.Game)
                .WithMany(g => g.PlayerStatistics)
                .HasForeignKey(ps => ps.GameID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PlayerStatistic>()
                .HasOne(ps => ps.Player)
                .WithMany(p => p.PlayerStatistics)
                .HasForeignKey(ps => ps.PlayerID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PlayerStatistic>()
                .HasOne(ps => ps.Team)
                .WithMany()
                .HasForeignKey(ps => ps.TeamID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<MatchScore>()
                .HasOne(ms => ms.Game)
                .WithMany(g => g.MatchScores)
                .HasForeignKey(ms => ms.GameID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<MatchScore>()
                .HasOne(ms => ms.Team)
                .WithMany()
                .HasForeignKey(ms => ms.TeamID)
                .OnDelete(DeleteBehavior.Restrict);

          


            modelBuilder.Entity<TeamViewModel>().HasNoKey().ToView("TeamView"); 
            modelBuilder.Entity<PlayerViewModel>().HasNoKey().ToView("PlayerView");
            modelBuilder.Entity<GameViewModel>().HasNoKey().ToView("GameView"); 
            modelBuilder.Entity<MatchScoreViewModel>().HasNoKey().ToView("MatchScoreView"); 
            modelBuilder.Entity<PlayerStatisticViewModel>().HasNoKey().ToView("PlayerStatisticView"); 
            modelBuilder.Entity<StaffViewModel>().HasNoKey().ToView("StaffView");
        }
    }
}
