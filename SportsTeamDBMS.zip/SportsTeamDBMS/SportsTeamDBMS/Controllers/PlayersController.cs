﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsTeamDBMS.Data;
using SportsTeamDBMS.Models;

namespace SportsTeamDBMS.Controllers
{
    public class PlayersController : Controller
    {
        private readonly SportsTeamDbContext _context;

        public PlayersController(SportsTeamDbContext context)
        {
            _context = context;
        }

        private async Task<IActionResult> GetPlayerIndexView(string viewName)
        {
            var players = await _context.Players.Include(p => p.Team).ToListAsync();
            return View(viewName, players);
        }

        // GET: Players/Index
        public async Task<IActionResult> Index() => await GetPlayerIndexView("Index");

        // GET: Players/EditIndex
        public async Task<IActionResult> EditIndex() => await GetPlayerIndexView("EditIndex");

        // GET: Players/DetailsIndex
        public async Task<IActionResult> DetailsIndex() => await GetPlayerIndexView("DetailsIndex");

        // GET: Players/PlayerReport
        public async Task<IActionResult> PlayerReport()
        {
            var playerView = await _context.PlayerView.ToListAsync();
            return View(playerView);
        }

        // GET: Players/DeleteIndex
        public async Task<IActionResult> DeleteIndex() => await GetPlayerIndexView("DeleteIndex");

        private async Task<Player> FindPlayerByID(int? id)
        {
            if (id == null)
            {
                return null;
            }

            var player = await _context.Players.Include(p => p.Team).FirstOrDefaultAsync(m => m.PlayerID == id);
            return player;
        }

        // GET: Players/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var player = await FindPlayerByID(id);
            if (player == null)
            {
                return NotFound();
            }

            return View(player);
        }

        // GET: Players/Create
        public IActionResult Create()
        {
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName");
            return View();
        }

        // POST: Players/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PlayerID,PlayerName,TeamID,Position,JerseyNumber,DateOfBirth,Nationality,JoiningDate")] Player player)
        {
            if (ModelState.IsValid)
            {
                _context.Add(player);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Player created successfully!";
                return RedirectToAction(nameof(Create));
            }
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", player.TeamID);
            return View(player);
        }

        // GET: Players/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var player = await FindPlayerByID(id);
            if (player == null)
            {
                return NotFound();
            }
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", player.TeamID);
            return View(player);
        }

        // POST: Players/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PlayerID,PlayerName,TeamID,Position,JerseyNumber,DateOfBirth,Nationality,JoiningDate")] Player player)
        {
            if (id != player.PlayerID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(player);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Player edited successfully!";
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!PlayerExists(player.PlayerID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw new Exception("Concurrency exception occurred", ex);
                    }
                }
                return RedirectToAction(nameof(Create));
            }
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", player.TeamID);
            return View(player);
        }

        // GET: Players/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var player = await FindPlayerByID(id);
            if (player == null)
            {
                return NotFound();
            }

            return View(player);
        }

        // POST: Players/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var player = await _context.Players.FindAsync(id);
            if (player != null)
            {
                _context.Players.Remove(player);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Player deleted successfully!";
            }
            return RedirectToAction(nameof(Create));
        }

        private bool PlayerExists(int id)
        {
            return _context.Players.Any(e => e.PlayerID == id);
        }
    }
}
