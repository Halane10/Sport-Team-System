﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsTeamDBMS.Data;
using SportsTeamDBMS.Models;

namespace SportsTeamDBMS.Controllers
{
    public class GamesController : Controller
    {
        private readonly SportsTeamDbContext _context;

        public GamesController(SportsTeamDbContext context)
        {
            _context = context;
        }

        private async Task<IActionResult> GetGameIndexView(string viewName)
        {
            var games = await _context.Games
                .Include(g => g.AwayTeam)
                .Include(g => g.HomeTeam)
                .ToListAsync();
            return View(viewName, games);
        }

        // GET: Games/Index
        public async Task<IActionResult> Index() => await GetGameIndexView("Index");

        // GET: Games/EditIndex
        public async Task<IActionResult> EditIndex() => await GetGameIndexView("EditIndex");

        // GET: Games/DetailsIndex
        public async Task<IActionResult> DetailsIndex() => await GetGameIndexView("DetailsIndex");

        // GET: Games/GameReport
        public async Task<IActionResult> GameReport()
        {
            var gameView = await _context.GameView.ToListAsync();
            return View(gameView);
        }

        // GET: Games/DeleteIndex
        public async Task<IActionResult> DeleteIndex() => await GetGameIndexView("DeleteIndex");

        private async Task<Game> FindGameByID(int? id)
        {
            if (id == null)
            {
                return null;
            }

            var game = await _context.Games
                .Include(g => g.AwayTeam)
                .Include(g => g.HomeTeam)
                .FirstOrDefaultAsync(m => m.GameID == id);
            return game;
        }

        // GET: Games/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var game = await FindGameByID(id);
            if (game == null)
            {
                return NotFound();
            }

            return View(game);
        }

        // GET: Games/Create
        public IActionResult Create()
        {
            ViewData["AwayTeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName");
            ViewData["HomeTeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName");
            return View();
        }

        // POST: Games/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("GameID,HomeTeamID,AwayTeamID,GameDate,Stadium,Referee,Result")] Game game)
        {
            if (ModelState.IsValid)
            {
                _context.Add(game);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Game created successfully!";
                return RedirectToAction(nameof(Create));
            }
            ViewData["AwayTeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", game.AwayTeamID);
            ViewData["HomeTeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", game.HomeTeamID);
            return View(game);
        }

        // GET: Games/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var game = await FindGameByID(id);
            if (game == null)
            {
                return NotFound();
            }
            ViewData["AwayTeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", game.AwayTeamID);
            ViewData["HomeTeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", game.HomeTeamID);
            return View(game);
        }

        // POST: Games/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("GameID,HomeTeamID,AwayTeamID,GameDate,Stadium,Referee,Result")] Game game)
        {
            if (id != game.GameID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(game);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Game edited successfully!";
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!GameExists(game.GameID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw new Exception("Concurrency exception occurred", ex);
                    }
                }
                return RedirectToAction(nameof(EditIndex));
            }
            ViewData["AwayTeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", game.AwayTeamID);
            ViewData["HomeTeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", game.HomeTeamID);
            return View(game);
        }

        // GET: Games/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var game = await FindGameByID(id);
            if (game == null)
            {
                return NotFound();
            }

            return View(game);
        }

        // POST: Games/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var game = await _context.Games.FindAsync(id);
            if (game != null)
            {
                _context.Games.Remove(game);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Game deleted successfully!";
            }

            return RedirectToAction(nameof(DeleteIndex));
        }

        private bool GameExists(int id)
        {
            return _context.Games.Any(e => e.GameID == id);
        }
    }
}
