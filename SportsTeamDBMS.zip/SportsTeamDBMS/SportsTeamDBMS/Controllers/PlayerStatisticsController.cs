﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsTeamDBMS.Data;
using SportsTeamDBMS.Models;

namespace SportsTeamDBMS.Controllers
{
    public class PlayerStatisticsController : Controller
    {
        private readonly SportsTeamDbContext _context;

        public PlayerStatisticsController(SportsTeamDbContext context)
        {
            _context = context;
        }

        private async Task<IActionResult> GetPlayerStatisticIndexView(string viewName)
        {
            var playerStatistics = await _context.PlayerStatistics
                .Include(p => p.Game)
                .Include(p => p.Player)
                .Include(p => p.Team)
                .ToListAsync();
            return View(viewName, playerStatistics);
        }

        // GET: PlayerStatistics/EditIndex
        public async Task<IActionResult> EditIndex() => await GetPlayerStatisticIndexView("EditIndex");

        // GET: PlayerStatistics/DetailsIndex
        public async Task<IActionResult> DetailsIndex() => await GetPlayerStatisticIndexView("DetailsIndex");

        // GET: PlayerStatistics/PlayerStatisticsReport
        public async Task<IActionResult> PlayerStatisticsReport()
        {
            var playerStatisticView = await _context.PlayerStatisticView.ToListAsync();
            return View(playerStatisticView);
        }

        // GET: PlayerStatistics/DeleteIndex
        public async Task<IActionResult> DeleteIndex() => await GetPlayerStatisticIndexView("DeleteIndex");

        private async Task<PlayerStatistic> FindPlayerStatisticByID(int? id)
        {
            if (id == null)
            {
                return null;
            }

            var playerStatistic = await _context.PlayerStatistics
                .Include(p => p.Game)
                .Include(p => p.Player)
                .Include(p => p.Team)
                .FirstOrDefaultAsync(m => m.PlayerStatID == id);
            return playerStatistic;
        }

        // GET: PlayerStatistics/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var playerStatistic = await FindPlayerStatisticByID(id);
            if (playerStatistic == null)
            {
                return NotFound();
            }

            return View(playerStatistic);
        }

        // GET: PlayerStatistics/Create
        public IActionResult Create()
        {
            ViewData["GameID"] = new SelectList(_context.Games, "GameID", "GameID");
            ViewData["PlayerID"] = new SelectList(_context.Players, "PlayerID", "PlayerName");
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName");
            return View();
        }

        // POST: PlayerStatistics/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PlayerStatID,GameID,PlayerID,TeamID,Goals,Assists,YellowCards,RedCards,MinutesPlayed")] PlayerStatistic playerStatistic)
        {
            if (ModelState.IsValid)
            {
                _context.Add(playerStatistic);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Player statistic created successfully!";
                return RedirectToAction(nameof(Create));
            }
            ViewData["GameID"] = new SelectList(_context.Games, "GameID", "GameID", playerStatistic.GameID);
            ViewData["PlayerID"] = new SelectList(_context.Players, "PlayerID", "PlayerName", playerStatistic.PlayerID);
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", playerStatistic.TeamID);
            return View(playerStatistic);
        }

        // GET: PlayerStatistics/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var playerStatistic = await FindPlayerStatisticByID(id);
            if (playerStatistic == null)
            {
                return NotFound();
            }
            ViewData["GameID"] = new SelectList(_context.Games, "GameID", "GameID", playerStatistic.GameID);
            ViewData["PlayerID"] = new SelectList(_context.Players, "PlayerID", "PlayerName", playerStatistic.PlayerID);
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", playerStatistic.TeamID);
            return View(playerStatistic);
        }

        // POST: PlayerStatistics/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PlayerStatID,GameID,PlayerID,TeamID,Goals,Assists,YellowCards,RedCards,MinutesPlayed")] PlayerStatistic playerStatistic)
        {
            if (id != playerStatistic.PlayerStatID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(playerStatistic);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Player statistic edited successfully!";
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!PlayerStatisticExists(playerStatistic.PlayerStatID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw new Exception("Concurrency exception occurred", ex);
                    }
                }
                return RedirectToAction(nameof(EditIndex));
            }
            ViewData["GameID"] = new SelectList(_context.Games, "GameID", "GameID", playerStatistic.GameID);
            ViewData["PlayerID"] = new SelectList(_context.Players, "PlayerID", "PlayerName", playerStatistic.PlayerID);
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", playerStatistic.TeamID);
            return View(playerStatistic);
        }

        // GET: PlayerStatistics/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var playerStatistic = await FindPlayerStatisticByID(id);
            if (playerStatistic == null)
            {
                return NotFound();
            }

            return View(playerStatistic);
        }

        // POST: PlayerStatistics/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var playerStatistic = await _context.PlayerStatistics.FindAsync(id);
            if (playerStatistic != null)
            {
                _context.PlayerStatistics.Remove(playerStatistic);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Player statistic deleted successfully!";
            }
            return RedirectToAction(nameof(DeleteIndex));
        }

        private bool PlayerStatisticExists(int id)
        {
            return _context.PlayerStatistics.Any(e => e.PlayerStatID == id);
        }
    }
}
