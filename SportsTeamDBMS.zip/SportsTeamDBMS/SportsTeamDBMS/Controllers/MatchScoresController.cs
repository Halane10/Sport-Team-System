﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsTeamDBMS.Data;
using SportsTeamDBMS.Models;

namespace SportsTeamDBMS.Controllers
{
    public class MatchScoresController : Controller
    {
        private readonly SportsTeamDbContext _context;

        public MatchScoresController(SportsTeamDbContext context)
        {
            _context = context;
        }

        private async Task<IActionResult> GetMatchScoreIndexView(string viewName)
        {
            var matchScores = await _context.MatchScores
                .Include(m => m.Game)
                .Include(m => m.Team)
                .ToListAsync();
            return View(viewName, matchScores);
        }

        // GET: MatchScores/Index
        public async Task<IActionResult> Index() => await GetMatchScoreIndexView("Index");

        // GET: MatchScores/EditIndex
        public async Task<IActionResult> EditIndex() => await GetMatchScoreIndexView("EditIndex");

        // GET: MatchScores/DetailsIndex
        public async Task<IActionResult> DetailsIndex() => await GetMatchScoreIndexView("DetailsIndex");

        // GET: MatchScores/MatchScoreReport
        public async Task<IActionResult> MatchScoreReport()
        {
            var matchScoreView = await _context.MatchScoreView.ToListAsync();
            return View(matchScoreView);
        }

        // GET: MatchScores/DeleteIndex
        public async Task<IActionResult> DeleteIndex() => await GetMatchScoreIndexView("DeleteIndex");

        private async Task<MatchScore> FindMatchScoreByID(int? id)
        {
            if (id == null)
            {
                return null;
            }

            var matchScore = await _context.MatchScores
                .Include(m => m.Game)
                .Include(m => m.Team)
                .FirstOrDefaultAsync(m => m.MatchScoreID == id);
            return matchScore;
        }

        // GET: MatchScores/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var matchScore = await FindMatchScoreByID(id);
            if (matchScore == null)
            {
                return NotFound();
            }

            return View(matchScore);
        }

        // GET: MatchScores/Create
        public IActionResult Create()
        {
            ViewData["GameID"] = new SelectList(_context.Games, "GameID", "GameID");
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName");
            return View();
        }

        // POST: MatchScores/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MatchScoreID,GameID,TeamID,GoalsScored")] MatchScore matchScore)
        {
            if (ModelState.IsValid)
            {
                _context.Add(matchScore);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Match score created successfully!";
                return RedirectToAction(nameof(Create));
            }
            ViewData["GameID"] = new SelectList(_context.Games, "GameID", "GameID", matchScore.GameID);
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", matchScore.TeamID);
            return View(matchScore);
        }

        // GET: MatchScores/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var matchScore = await FindMatchScoreByID(id);
            if (matchScore == null)
            {
                return NotFound();
            }
            ViewData["GameID"] = new SelectList(_context.Games, "GameID", "GameID", matchScore.GameID);
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", matchScore.TeamID);
            return View(matchScore);
        }

        // POST: MatchScores/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("MatchScoreID,GameID,TeamID,GoalsScored")] MatchScore matchScore)
        {
            if (id != matchScore.MatchScoreID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(matchScore);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Match score edited successfully!";
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!MatchScoreExists(matchScore.MatchScoreID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw new Exception("Concurrency exception occurred", ex);
                    }
                }
                return RedirectToAction(nameof(EditIndex));
            }
            ViewData["GameID"] = new SelectList(_context.Games, "GameID", "GameID", matchScore.GameID);
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", matchScore.TeamID);
            return View(matchScore);
        }

        // GET: MatchScores/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var matchScore = await FindMatchScoreByID(id);
            if (matchScore == null)
            {
                return NotFound();
            }

            return View(matchScore);
        }

        // POST: MatchScores/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var matchScore = await _context.MatchScores.FindAsync(id);
            if (matchScore != null)
            {
                _context.MatchScores.Remove(matchScore);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Match score deleted successfully!";
            }
            return RedirectToAction(nameof(DeleteIndex));
        }

        private bool MatchScoreExists(int id)
        {
            return _context.MatchScores.Any(e => e.MatchScoreID == id);
        }
    }
}
