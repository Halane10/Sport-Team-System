﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsTeamDBMS.Data;
using SportsTeamDBMS.Models;

namespace SportsTeamDBMS.Controllers
{
    public class StaffsController : Controller
    {
        private readonly SportsTeamDbContext _context;

        public StaffsController(SportsTeamDbContext context)
        {
            _context = context;
        }

        private async Task<IActionResult> GetStaffIndexView(string viewName)
        {
            var staffs = await _context.Staffs.Include(s => s.Team).ToListAsync();
            return View(viewName, staffs);
        }

        // GET: Staffs/Index
        public async Task<IActionResult> Index() => await GetStaffIndexView("Index");

        // GET: Staffs/EditIndex
        public async Task<IActionResult> EditIndex() => await GetStaffIndexView("EditIndex");

        // GET: Staffs/DetailsIndex
        public async Task<IActionResult> DetailsIndex() => await GetStaffIndexView("DetailsIndex");

        // GET: Staffs/DeleteIndex
        public async Task<IActionResult> DeleteIndex() => await GetStaffIndexView("DeleteIndex");
        public async Task<IActionResult> StaffReport()
        {
            var StaffViewModel = await _context.StaffView.ToListAsync();
            return View(StaffViewModel);
        }

        private async Task<Staff> FindStaffByID(int? id)
        {
            if (id == null)
            {
                return null;
            }

            var staff = await _context.Staffs.Include(s => s.Team).FirstOrDefaultAsync(m => m.StaffID == id);
            return staff;
        }

        // GET: Staffs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var staff = await FindStaffByID(id);
            if (staff == null)
            {
                return NotFound();
            }

            return View(staff);
        }

        // GET: Staffs/Create
        public IActionResult Create()
        {
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName");
            return View();
        }

        // POST: Staffs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StaffID,StaffName,Role,TeamID")] Staff staff)
        {
            if (ModelState.IsValid)
            {
                _context.Add(staff);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Staff created successfully!";
                return RedirectToAction(nameof(Create));
            }
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", staff.TeamID);
            return View(staff);
        }

        // GET: Staffs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var staff = await FindStaffByID(id);
            if (staff == null)
            {
                return NotFound();
            }
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", staff.TeamID);
            return View(staff);
        }

        // POST: Staffs/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("StaffID,StaffName,Role,TeamID")] Staff staff)
        {
            if (id != staff.StaffID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(staff);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Staff updated successfully!";
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!StaffExists(staff.StaffID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw new Exception("Concurrency exception occurred", ex);
                    }
                }
                return RedirectToAction(nameof(Create));
            }
            ViewData["TeamID"] = new SelectList(_context.Teams, "TeamID", "TeamName", staff.TeamID);
            return View(staff);
        }

        // GET: Staffs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var staff = await FindStaffByID(id);
            if (staff == null)
            {
                return NotFound();
            }

            return View(staff);
        }

        // POST: Staffs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var staff = await _context.Staffs.FindAsync(id);
            if (staff != null)
            {
                _context.Staffs.Remove(staff);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Staff deleted successfully!";
            }
            return RedirectToAction(nameof(Create));
        }

        private bool StaffExists(int id)
        {
            return _context.Staffs.Any(e => e.StaffID == id);
        }
    }
}
