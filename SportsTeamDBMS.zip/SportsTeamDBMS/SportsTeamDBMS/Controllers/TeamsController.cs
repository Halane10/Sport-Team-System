﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsTeamDBMS.Data;
using SportsTeamDBMS.Models;

namespace SportsTeamDBMS.Controllers
{
    public class TeamsController : Controller
    {
        private readonly SportsTeamDbContext _context;

        public TeamsController(SportsTeamDbContext context)
        {
            _context = context;
        }

        private async Task<IActionResult> GetTeamIndexView(string viewName)
        {
            var teams = await _context.Teams.ToListAsync();
            return View(viewName, teams);
        }

        // GET: Teams/Index
        public async Task<IActionResult> Index() => await GetTeamIndexView("Index");

        // GET: Teams/EditIndex
        public async Task<IActionResult> EditIndex() => await GetTeamIndexView("EditIndex");

        // GET: Teams/DetailsIndex
        public async Task<IActionResult> DetailsIndex() => await GetTeamIndexView("DetailsIndex");

        // GET: Teams/DeleteIndex
        public async Task<IActionResult> DeleteIndex() => await GetTeamIndexView("DeleteIndex");

        // GET: Teams/TeamReport
        public async Task<IActionResult> TeamReport()
        {
            var TeamViewModel = await _context.TeamView.ToListAsync();
            return View(TeamViewModel);
        }

        private async Task<Team> FindTeamByID(int? id)
        {
            if (id == null)
            {
                return null;
            }

            var team = await _context.Teams.FirstOrDefaultAsync(m => m.TeamID == id);
            return team ?? new Team(); // Return a new Team object to avoid null references
        }
 

        // GET: Teams/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var team = await FindTeamByID(id);
            if (team == null)
            {
                return NotFound();
            }

            return View(team);
        }

        // GET: Teams/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Teams/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TeamID,TeamName,City,CoachName,Stadium,EstablishedYear")] Team team)
        {
            if (ModelState.IsValid)
            {
                _context.Add(team);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Team created successfully!";
                return RedirectToAction(nameof(Create));
            }
            return View(team);
        }

        // GET: Teams/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var team = await FindTeamByID(id);
            if (team == null)
            {
                return NotFound();
            }

            return View(team);
        }

        // POST: Teams/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("TeamID,TeamName,City,CoachName,Stadium,EstablishedYear")] Team team)
        {
            if (id != team.TeamID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(team);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Team updated successfully!";
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!TeamExists(team.TeamID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw new Exception("Concurrency exception occurred", ex);
                    }
                }
                return RedirectToAction(nameof(Create));
            }
            return View(team);
        }

        // GET: Teams/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var team = await FindTeamByID(id);
            if (team == null)
            {
                return NotFound();
            }

            return View(team);
        }

        // POST: Teams/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var team = await _context.Teams.FindAsync(id);
            if (team != null)
            {
                _context.Teams.Remove(team);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Team deleted successfully!";
            }
            return RedirectToAction(nameof(Create));
        }

        private bool TeamExists(int id)
        {
            return _context.Teams.Any(e => e.TeamID == id);
        }
    }
}
