using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SportsTeamDBMS;
using SportsTeamDBMS.Models;
using SportsTeamDBMS.Data;

var builder = WebApplication.CreateBuilder(args);

// Configure Database Context
builder.Services.AddDbContext<SportsTeamDbContext>(
    options => options.UseSqlServer(builder.Configuration.GetConnectionString("MyConnection")));

// Configure Identity
builder.Services.AddIdentity<Users, IdentityRole>(options =>
{
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequiredLength = 8;
    options.Password.RequireUppercase = false;
    options.Password.RequireLowercase = false;
    options.User.RequireUniqueEmail = true;
})
.AddEntityFrameworkStores<SportsTeamDbContext>()
.AddDefaultTokenProviders();
// Add token providers for password resets, etc.

// Add MVC services
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error"); // Custom error handling
    app.UseHsts(); // Use HSTS in production
}

app.UseHttpsRedirection(); // Redirect HTTP to HTTPS
app.UseStaticFiles(); // Enable serving static files

app.UseRouting();

app.UseAuthentication(); // Enable Authentication Middleware
app.UseAuthorization(); // Enable Authorization Middleware

app.UseEndpoints(endpoints =>
{
    // Default route configuration
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");
});

app.Run();
